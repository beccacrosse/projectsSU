#include "LeapfrogHashTable.h"
#include "GUI/SimpleTest.h"
using namespace std;

LeapfrogHashTable::LeapfrogHashTable(HashFunction<string> hashFn) {
    /* TODO: Delete this comment and the line below it, then implement this function. */
    (void) hashFn;
}

LeapfrogHashTable::~LeapfrogHashTable() {
    /* TODO: Delete this comment, then implement this function. */
}

bool LeapfrogHashTable::contains(const string& key) const {
    /* TODO: Delete this comment and the lines below it, then implement this function. */
    (void) key;
    return false;
}

bool LeapfrogHashTable::insert(const string& key) {
    /* TODO: Delete this comment and the lines below it, then implement this function. */
    (void) key;
    return false;
}

int LeapfrogHashTable::size() const {
    /* TODO: Delete this comment and the line below it, then implement this function. */
    return -1;
}

bool LeapfrogHashTable::isEmpty() const {
    /* TODO: Delete this comment and the line below it, then implement this function. */
    return false;
}

void LeapfrogHashTable::printDebugInfo() const {
    /* TODO: Delete this comment, then optionally add code to this function. */
}

/* Space for test cases. You are not required to write any test cases, but you
 * are encouraged to do so because our test coverage is not as extensive as what
 * you saw in Assignment 7.
 */
