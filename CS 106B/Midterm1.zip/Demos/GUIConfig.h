WINDOW_TITLE("CS106B Midterm I")

INITIAL_HANDLER("TestingGUI.cpp")

TEST_ORDER("SandpilesRevisited.cpp",
           "HapaxLegomena.cpp",
           "TheLatestAttraction.cpp",
           "SocialDistancing.cpp")
