#pragma once

namespace MiniGUI {
    namespace Detail {
        void consoleMain();
    }
}
