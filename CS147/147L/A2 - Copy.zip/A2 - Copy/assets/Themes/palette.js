// Feel free to customize these to your liking or define new colors!
export const palette = {
  white: "#FFFFFF",
  lightPink: "#FDDDE6",
  darkPink: "#FFBEC8",
  lightRed: "#FF6961",
  lightGray: "#F3F3F3",
  black: "#000000",
  lightBlack: "#121416",
  lighterBlack: "#202224",
};
